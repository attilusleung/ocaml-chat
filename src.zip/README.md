# ocaml-chat
A Terminal Based Server/Client Chatroom

[Installation Instructions](INSTALL.md)
